import { Queue } from 'bullmq';
import IORedis from 'ioredis';

export const redis = new IORedis(process.env.REDIS_URL ?? 'redis://localhost:6379', {
  maxRetriesPerRequest: null,
});

export interface FixJob {
  installationId: number;
  repoFullName: string;
  repoCloneUrl: string;
  headSha: string;
  headBranch: string;
  workflowRunId: number;
  workflowName: string;
  attempt?: number; // Bot tự quản lý retry count
}

export const fixQueue = new Queue<FixJob>('ci-fix', {
  connection: redis,
  defaultJobOptions: {
    removeOnComplete: { age: 86400, count: 1000 },
    removeOnFail: { age: 86400 * 7 },
  },
});
